/* SSE Store — unlimited products via IndexedDB (not 5MB localStorage).
   Public pages read paginated. Admin writes unlimited. Export shards for Vercel. */
const SSE = (() => {
  const DB = 'sse_db', LS_FALLBACK = 'sse_products_fb';
  const PAGE = 48;
  let mem = [];
  const $ = (s, r=document) => r.querySelector(s);

  function idb() {
    return new Promise((res, rej) => {
      try {
        const q = indexedDB.open(DB, 1);
        q.onupgradeneeded = () => q.result.createObjectStore('products', { keyPath: 'id' });
        q.onsuccess = () => res(q.result);
        q.onerror = () => rej(q.error);
      } catch (e) { rej(e); }
    });
  }
  async function all() {
    try {
      const db = await idb();
      return await new Promise((res, rej) => {
        const tx = db.transaction('products').objectStore('products').getAll();
        tx.onsuccess = () => res(tx.result || []);
        tx.onerror = () => rej(tx.error);
      });
    } catch { try { return JSON.parse(localStorage.getItem(LS_FALLBACK) || '[]'); } catch { return mem; } }
  }
  async function put(p) {
    try {
      const db = await idb();
      await new Promise((res, rej) => {
        const tx = db.transaction('products', 'readwrite').objectStore('products').put(p);
        tx.onsuccess = res; tx.onerror = () => rej(tx.error);
      });
    } catch { const a = await all(); const i = a.findIndex(x => x.id === p.id); if (i >= 0) a[i] = p; else a.push(p); localStorage.setItem(LS_FALLBACK, JSON.stringify(a)); }
  }
  async function seed() {
    const have = await all();
    if (have.length) return have;
    try {
      const r = await fetch('data/catalog-001.json');
      const j = await r.json();
      for (const p of j.products) await put(p);
      localStorage.setItem('sse_content', JSON.stringify(j.content));
      return j.products;
    } catch { return []; }
  }
  const content = () => { try { return JSON.parse(localStorage.getItem('sse_content') || '{}'); } catch { return {}; } };
  const saveContent = c => localStorage.setItem('sse_content', JSON.stringify(c));
  const fmt = n => '₹ ' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  // Escape anything rendered via innerHTML: product names (admin/CSV import),
  // order text (public form), customer names. Prevents stored XSS.
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // Product images are admin-pasted URLs — allow http(s) only, else placeholder.
  const safeImg = u => { try { const x = new URL(u, location.href); if (x.protocol === 'http:' || x.protocol === 'https:') return x.href; } catch {} return 'assets/img/cat-p21.png'; };

  function filter(list, q, cat) {
    q = (q || '').toLowerCase();
    return list.filter(p =>
      (!cat || p.category === cat) &&
      (!q || (p.name + ' ' + (p.brand || '')).toLowerCase().includes(q)));
  }
  function page(list, n) { return list.slice((n - 1) * PAGE, n * PAGE); }

  /* Billing helpers */
  const seq = () => {
    const k = 'sse_seq', v = Number(localStorage.getItem(k) || '1');
    localStorage.setItem(k, String(v + 1));
    const fy = '25-26'; return `SSE/${fy}/${String(v).padStart(4, '0')}`;
  };
  function totals(items, discount = 0) {
    let sub = 0, gst = 0;
    for (const it of items) { const t = it.qty * it.rate; sub += t; gst += t * (it.gst_pct / 100); }
    const grand = Math.round(sub + gst - discount);
    return { sub, gst, grand };
  }
  /* Activity Logging & Auditing */
  function logActivity(type, title, detail, meta = {}) {
    try {
      const a = JSON.parse(localStorage.getItem('sse_activities') || '[]');
      const entry = {
        id: 'ACT-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase(),
        type: String(type || 'SYSTEM').toUpperCase(),
        title: String(title || ''),
        detail: String(detail || ''),
        meta: meta || {},
        time: new Date().toISOString()
      };
      a.unshift(entry);
      localStorage.setItem('sse_activities', JSON.stringify(a.slice(0, 1000)));
      return entry;
    } catch { return null; }
  }

  function getActivities(filterType = '') {
    try {
      let a = JSON.parse(localStorage.getItem('sse_activities') || '[]');
      if (!a.length) a = seedActivities();
      if (!filterType || filterType === 'all') return a;
      return a.filter(x => x.type === filterType.toUpperCase());
    } catch { return []; }
  }

  function seedActivities() {
    const samples = [
      {
        id: 'ACT-SYS-101',
        type: 'BILL',
        title: 'GST Tax Invoice SSE/25-26/0142 Generated',
        detail: 'Daikin Airconditioning Plant 2 · ₹ 18,450 (UPI Settled)',
        meta: { no: 'SSE/25-26/0142', customer: 'Daikin Airconditioning Plant 2', amount: 18450, mode: 'UPI' },
        time: new Date(Date.now() - 18 * 60 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-102',
        type: 'STOCK',
        title: 'Stock Inward: +50 SKF 6205-2RSH Bearings',
        detail: 'Warehouse Lake 1 Restock · Minimum buffer restored',
        meta: { id: 'SKF-6205-2RS', delta: 50, reason: 'OEM Restock' },
        time: new Date(Date.now() - 55 * 60 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-103',
        type: 'PAYMENT',
        title: 'Plant Credit Collection: ₹ 24,000 Received',
        detail: 'Havells India Ltd (Neemrana Unit) · Net 30 Ledger Settlement',
        meta: { customer: 'Havells India Ltd', amount: 24000, mode: 'NEFT' },
        time: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-104',
        type: 'ORDER',
        title: 'Web Inward Request Confirmed: ORD-8841',
        detail: 'Mitsui Kinzoku Components · 12x Polymatic 5/2 Solenoid Valves',
        meta: { id: 'ORD-8841', status: 'confirmed' },
        time: new Date(Date.now() - 3.5 * 3600 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-105',
        type: 'BILL',
        title: 'Estimate EST-9021 Issued for BOQ Clearance',
        detail: 'Hero MotoCorp Ancillary · 40x Fenner V-Belts (₹ 14,280)',
        meta: { no: 'EST-9021', customer: 'Hero MotoCorp Ancillary', amount: 14280, mode: 'Estimate' },
        time: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-106',
        type: 'PRODUCT',
        title: 'Price Matrix Updated: Bosch GWS 750-100 Angle Grinder',
        detail: 'Wholesale adjusted to ₹ 2,350 · Retail ₹ 2,650 (GST 18%)',
        meta: { name: 'Bosch GWS 750-100' },
        time: new Date(Date.now() - 7 * 3600 * 1000).toISOString()
      },
      {
        id: 'ACT-SYS-107',
        type: 'STOCK',
        title: 'Stock Dispatched: -8 Polymatic FRL Units',
        detail: 'Invoice SSE/25-26/0141 · Dispatched to Japanese Zone 1',
        meta: { delta: -8, reason: 'Sale Dispatch' },
        time: new Date(Date.now() - 8.5 * 3600 * 1000).toISOString()
      }
    ];
    try {
      localStorage.setItem('sse_activities', JSON.stringify(samples));
    } catch {}
    return samples;
  }

  function logStock(id, delta, reason) {
    try {
      const a = JSON.parse(localStorage.getItem('sse_stocklog') || '[]');
      a.push({ id, delta, reason, date: new Date().toISOString() });
      localStorage.setItem('sse_stocklog', JSON.stringify(a.slice(-2000)));
      logActivity('STOCK', (delta > 0 ? 'Stock Added: +' : 'Stock Deducted: ') + Math.abs(delta) + ' units (' + id + ')', `Reason: ${reason}`, { id, delta, reason });
    } catch {}
  }

  /* Reveal + tagline (single observer, no scroll listeners) */
  function motion() {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
    document.querySelectorAll('.rv').forEach(el => io.observe(el));
    const words = document.querySelectorAll('.tagline .w');
    if (!words.length) return;
    const wio = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); wio.unobserve(e.target); } }), { threshold: .6, rootMargin: '0px 0px -40% 0px' });
    words.forEach((w, i) => { w.style.transitionDelay = (i * 40) + 'ms'; wio.observe(w); });
  }

  /* Update mobile bottom navigation cart badge & active states */
  function updateNavBadge() {
    try {
      const cart = JSON.parse(localStorage.getItem('sse_cart') || '[]');
      const count = cart.reduce((a, c) => a + (Number(c.qty) || 0), 0);
      const badges = document.querySelectorAll('.nav-badge, [data-nav-badge]');
      badges.forEach(b => {
        if (count > 0) {
          b.textContent = count;
          b.style.display = 'inline-block';
        } else {
          b.textContent = '0';
          b.style.display = 'none';
        }
      });
    } catch {}
  }

  /* Enterprise footer — clean corporate layout without mobile bottom nav buttons */
  function footer(){
    const path=(location.pathname.split('/').pop()||'index.html').toLowerCase();
    if(path.includes('admin')||path.includes('bill'))return;
    const c=SSE.content();
    let f=document.querySelector('footer.sfooter');
    if(!f){f=document.createElement('footer');f.className='sfooter';document.body.appendChild(f);}
    const yr=new Date().getFullYear();
    f.innerHTML=`<div class="wrap cols">
    <div class="fbrand"><a class="brand" href="index.html" style="filter:invert(0)"><span class="brand-mark">S</span><span style="color:#fff">Shree Shyam<small style="color:#8FA5D4">Industrial & Project Suppliers</small></span></a>
    <p>Bearings, belts, fasteners, pneumatics, tools and industrial electricals for plants that cannot stop. Authorized Polymatic Pneumatic distributor since 2009.</p>
    </div>
    <div><h5>Catalogue</h5><a href="shop.html">All items</a><a href="checkout.html">Checkout</a><a href="index.html#bulk">Project desk</a><a href="account.html">Your account</a></div>
    <div><h5>Reach us</h5><a href="tel:+917240107540">72401 07540</a><a href="tel:+9188797979884">98879 79884</a><a href="https://wa.me/917240107540">WhatsApp us</a><a href="mailto:shreeshyamenterprises7540@gmail.com">Email</a></div>
    <div><h5>Counter</h5><span>Shop No. 191, RIICO Hanuman Market Complex, Neemrana (Alwar), Rajasthan 301705</span><span>Open 9 to 8 · all days</span><span>GSTIN ${SSE.esc(c.gstin||'08SJHPS7017F1ZK')}</span></div>
    </div>
    <div class="wrap legal"><span>© ${yr} Shree Shyam Enterprises · Industrial & Project Suppliers</span>
    <span class="lgl"><a href="privacy.html">Privacy</a><a href="terms.html">Terms</a><a href="sitemap.xml">Sitemap</a></span></div>
    <div class="giant" aria-hidden="true">SHREE SHYAM</div>`;
    updateNavBadge();
    initLiquidNav();
  }

  /* WhatsApp-style swappable liquid glass bottom navigation */
  function initLiquidNav() {
    const nav = document.querySelector('.mtabs');
    if (!nav || nav.__sse_swapped__) return;
    nav.__sse_swapped__ = true;
    const links = Array.from(nav.querySelectorAll('a'));
    if (!links.length) return;

    let startX = 0, startY = 0;
    nav.addEventListener('touchstart', e => {
      startX = e.changedTouches[0].screenX;
      startY = e.changedTouches[0].screenY;
    }, { passive: true });

    nav.addEventListener('touchend', e => {
      const diffX = e.changedTouches[0].screenX - startX;
      const diffY = e.changedTouches[0].screenY - startY;
      if (Math.abs(diffX) > 42 && Math.abs(diffX) > Math.abs(diffY) * 1.4) {
        const currentIdx = links.findIndex(a => a.classList.contains('on'));
        if (currentIdx !== -1) {
          if (diffX < 0 && currentIdx < links.length - 1) {
            links[currentIdx + 1].click();
          } else if (diffX > 0 && currentIdx > 0) {
            links[currentIdx - 1].click();
          }
        }
      }
    }, { passive: true });

    // Global Cmd+K / Ctrl+K search shortcut (Figma / Webflow pattern)
    window.addEventListener('keydown', e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const qInput = document.getElementById('q');
        if (qInput) {
          qInput.focus();
          qInput.select();
        } else {
          window.location.href = 'shop.html';
        }
      }
    });
  }

  /* Inspora.design live category filter tab handler */
  function initInsporaFeed() {
    const tabs = document.querySelectorAll('#insporaTabs .inspora-tab-btn');
    const cards = document.querySelectorAll('#insporaFeed .inspora-card');
    if (!tabs.length || !cards.length) return;

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const filter = tab.getAttribute('data-filter') || 'all';

        cards.forEach(card => {
          const cat = card.getAttribute('data-category');
          if (filter === 'all' || cat === filter) {
            card.style.display = 'block';
            card.style.opacity = '0';
            card.style.transform = 'translateY(12px)';
            requestAnimationFrame(() => {
              card.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
              card.style.opacity = '1';
              card.style.transform = 'translateY(0)';
            });
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }

  /* EventBeds™ Luxury Header Menu and Drawer Controller */
  function initEventBedsHeader() {
    const menuBtn = document.getElementById('menuBtn');
    const drawer = document.getElementById('mmenu');
    const drawerClose = document.getElementById('drawerClose');

    if (!menuBtn || !drawer) return;

    function toggleMenu(open) {
      const isOpen = open !== undefined ? open : !drawer.classList.contains('open');
      if (isOpen) {
        drawer.classList.add('open');
        document.body.classList.add('menu-open');
        menuBtn.setAttribute('aria-expanded', 'true');
      } else {
        drawer.classList.remove('open');
        document.body.classList.remove('menu-open');
        menuBtn.setAttribute('aria-expanded', 'false');
      }
    }

    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    if (drawerClose) {
      drawerClose.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleMenu(false);
      });
    }

    // Close on clicking backdrop/outside drawer
    document.addEventListener('click', (e) => {
      if (drawer.classList.contains('open') && !drawer.contains(e.target) && !menuBtn.contains(e.target)) {
        toggleMenu(false);
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && drawer.classList.contains('open')) {
        toggleMenu(false);
      }
    });
  }

  function initApp() {
    footer();
    initInsporaFeed();
    initEventBedsHeader();
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initApp);else initApp();

  return { all, put, seed, filter, page, PAGE, content, saveContent, fmt, esc, safeImg, seq, totals, logStock, logActivity, getActivities, seedActivities, motion, footer, updateNavBadge, initInsporaFeed, initEventBedsHeader, $ };
})();



